# UK Railway Stations — reference data

`uk-stations.csv` — every Great Britain National Rail station that has a CRS
(3-letter Computer Reservation System) code.

| Column    | Meaning                                             |
|-----------|-----------------------------------------------------|
| `crs`     | 3-letter CRS code — the station primary key         |
| `name`    | Station name                                        |
| `lat`     | Latitude (WGS84)                                    |
| `lon`     | Longitude (WGS84)                                   |
| `country` | `england` / `scotland` / `wales`                    |

- **Count:** 2,605 stations.
- **Scope:** Great Britain National Rail (England, Scotland, Wales). Northern Ireland
  (NI Railways / Translink) is a separate network and is **not** included.
- **Maps directly to the `stations` table:** `crs → crs`, `name → name`,
  `lat → lat`, `lon → lon`. (`country` is extra context, not a `stations` column.)
- **Not included:** official **NLC** and **TIPLOC** codes. Those come from the
  auth-gated RDG / Network Rail reference feed (CORPUS / BPLAN) — i.e. the GBR /
  company data feed. Enrich `stations.nlc` / `stations.tiploc` from that when
  available (see `docs/tech-debt.md` §C1).

**Source:** OpenStreetMap-derived station list
(`github.com/davwheat/uk-railway-stations`), © OpenStreetMap contributors, ODbL.
This matches the set the project seeds via `scripts/seed_stations.py`.

**Generated:** 2026-06-04.
